package member.dto;

public class MemberDTO {

}
