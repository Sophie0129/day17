package member.dao;

public class MemberDAO {

}
