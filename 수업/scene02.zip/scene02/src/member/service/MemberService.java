package member.service;

import javafx.scene.Parent;

public interface MemberService {
	public void setRoot( Parent root );
	public void registerFunc();
	public void cancelFunc();
}
