package common;

public interface CommonService {

}
